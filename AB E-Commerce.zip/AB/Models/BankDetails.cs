﻿public class BankDetails
{
    public int Id { get; set; }
    public string BankName { get; set; }
    public string AccountName { get; set; }
    public string AccountType { get; set; }
    public string AccountNumber { get; set; }
    public string BranchCode { get; set; }
    public string ReferenceInstructions { get; set; }
}
