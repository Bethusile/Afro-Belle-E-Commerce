﻿namespace AB.Helpers
{
    public class UpdateTotalRequest
    {
        public decimal TotalAmount { get; set; }
        public decimal ShippingFee { get; set; }
        public decimal DiscountAmount { get; set; }
    }
}
